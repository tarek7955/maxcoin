<a href="availabilities.php" class="btn btn-default mt15 mb15">
    <i class="fa fa-calendar"></i> <?php echo $texts['AVAILABILITIES']; ?>
</a>
