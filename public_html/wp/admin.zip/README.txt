Panda Resort 7 for single Hotel
Documentation: https://resort.pandao.eu/doc/
Author: Pandao
Web: https://items.pandao.eu
